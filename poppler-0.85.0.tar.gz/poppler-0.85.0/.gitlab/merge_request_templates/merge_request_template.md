Please make sure you check the "Allow commits from members who can merge to the target branch" option at the bottom of the page.

Makes our life much easier since we can rebase and merge from the web user interface.
